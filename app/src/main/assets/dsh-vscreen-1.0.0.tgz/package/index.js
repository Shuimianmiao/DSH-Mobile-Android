// dsh-vscreen —— 把「受信任虚拟屏」的取画面 / 操作能力做成 DSH 原生工具。
//
// 方案与两个守护（dsh.VsDaemon / dsh.ShellDaemon）由群友「如月雨露」制作，
// 本插件是随 App 分发的客户端：**只做请求转发**，一行权限判断都不做 ——
// 边界全在 App 与守护那边（守护只绑回环 + 每个请求校验 X-Token）。
//
// 三条通道，各管一段：
//   · :18240（虚拟屏守护）—— 列屏 / 取帧 / 改分辨率 / 把应用放上虚拟屏；
//   · :18242（命令端点守护）—— 以 shell 身份跑命令（点按就是 `input -d <id> tap x y`）；
//   · :3099（App 手机控制桥）—— 唯一能"把守护拉起来"的地方（它走 Shizuku，shell 身份）。
//
// 为什么点按要绕 :18242 而不是让守护自己实现：`input` 是系统命令，
// shell 身份直接就能跑，而且 `input -d <displayId>` 的坐标语义与虚拟屏一致 ——
// 守护再实现一套注入反而多一份要维护的代码（文档里那条"进程内注入"至今也没落地）。
//
// 零第三方依赖：插件随 APK 附带、在离线容器里安装，多一个依赖就多一个装不上的理由。
import fs from 'node:fs'
import http from 'node:http'
import path from 'node:path'
import os from 'node:os'
import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'vscreen'
export const inject = ['tools']

const PORT_VSD = 18240
const PORT_SHD = 18242
const PORT_BRIDGE = 3099

/** token 由 App 写进容器：/run/dsh-vsd/token（App 每次启动容器重写一份）。 */
const TOKEN_FILES = ['/run/dsh-vsd/token', '/sdcard/dsh/.vsd-token']
/** 手机控制桥的 token（只有"拉起守护"这一步要它）。 */
const BRIDGE_TOKEN_FILES = ['/run/dsh-phone/token', '/sdcard/dsh/.phone-token']

function readFirst(files) {
  for (const p of files) {
    try {
      const t = fs.readFileSync(p, 'utf8').trim()
      if (t) return t
    } catch (e) { /* 试下一个 */ }
  }
  return ''
}

function token() {
  const t = readFirst(TOKEN_FILES)
  if (!t) throw new Error('读不到虚拟屏 token（/run/dsh-vsd/token）—— 先调 vscreen_ensure 装一次')
  return t
}

/** 通用 HTTP：返回 { code, headers, body(Buffer) }。 */
function req(port, apiPath, { method = 'GET', body = null, timeoutMs = 15000, tok = null } = {}) {
  return new Promise((resolve, reject) => {
    const headers = {}
    if (tok) headers['X-Token'] = tok
    if (body !== null && body !== undefined) {
      headers['Content-Type'] = 'text/plain; charset=utf-8'
      headers['Content-Length'] = Buffer.byteLength(body)
    }
    const r = http.request({ host: '127.0.0.1', port, path: apiPath, method, headers, timeout: timeoutMs },
      (res) => {
        const chunks = []
        res.on('data', (d) => chunks.push(d))
        res.on('end', () => resolve({ code: res.statusCode, body: Buffer.concat(chunks) }))
      })
    r.on('error', (e) => reject(new Error('连不上 127.0.0.1:' + port + '（' + e.message + '）')))
    r.on('timeout', () => r.destroy(new Error('响应超时')))
    if (body !== null && body !== undefined) r.write(body)
    r.end()
  })
}

/** 取 JSON 文本（守护没起来 / 没鉴权时给出人话）。 */
async function vsGet(apiPath) {
  const res = await req(PORT_VSD, apiPath, { tok: token() })
  if (res.code === 403) throw new Error('守护拒绝了请求（X-Token 不对）—— 重新 vscreen_ensure 一次')
  if (res.code !== 200) throw new Error('守护返回 HTTP ' + res.code)
  return res.body.toString('utf8')
}

/** 走 :18242 以 shell 身份跑一条命令。 */
async function shd(cmd) {
  const res = await req(PORT_SHD, '/exec', { method: 'POST', body: cmd, timeoutMs: 60000, tok: token() })
  if (res.code === 403) throw new Error('命令端点拒绝了请求（X-Token 不对）')
  return res.body.toString('utf8')
}

/** 走 App 桥（拉起/停止守护用；那一步只有 App 有 shell 身份）。 */
async function bridge(op) {
  const t = readFirst(BRIDGE_TOKEN_FILES)
  if (!t) throw new Error('读不到手机控制桥的 token（/run/dsh-phone/token）—— App 在运行吗？')
  const res = await req(PORT_BRIDGE, '/vscreen?token=' + encodeURIComponent(t) + '&op=' + encodeURIComponent(op),
    { timeoutMs: 120000 })
  const text = res.body.toString('utf8')
  if (/^ERROR/.test(text)) throw new Error(text.trim())
  return text
}

/** 从 /list 的 JSON 里找第 i 块屏的 displayId。 */
function displayIdOf(listJson, i) {
  let arr
  try { arr = JSON.parse(listJson) } catch (e) { throw new Error('守护返回的不是 JSON：' + listJson.slice(0, 200)) }
  if (!Array.isArray(arr) || !arr.length) throw new Error('守护在跑，但一块屏都没有：' + listJson.slice(0, 200))
  const hit = arr.find((s) => Number(s.i) === Number(i))
  if (!hit) throw new Error('没有第 ' + i + ' 块屏（现在有 ' + arr.length + ' 块：' +
    arr.map((s) => s.i + '→displayId ' + s.displayId).join(', ') + '）')
  return hit
}

/** 取帧并存成 jpg，返回容器里的路径（拿到后直接 read_image 读它）。 */
async function shot(i, w) {
  const listJson = await vsGet('/list')
  const slot = displayIdOf(listJson, i)
  const q = w ? ('?w=' + Number(w)) : ''
  const res = await req(PORT_VSD, '/' + slot.i + '/frame' + q, { tok: token(), timeoutMs: 20000 })
  if (res.code !== 200) throw new Error('取帧失败：HTTP ' + res.code + ' ' + res.body.toString('utf8').slice(0, 120))
  if (res.body.length < 1024) throw new Error('这一帧还没准备好（' + res.body.toString('utf8').slice(0, 60) + '），稍等半秒再试')
  const dir = path.join(os.homedir(), '.dsh-vscreen')
  fs.mkdirSync(dir, { recursive: true })
  const file = path.join(dir, 'shot-' + slot.i + '-' + Date.now() + '.jpg')
  fs.writeFileSync(file, res.body)
  return file
}

const ensureNote = '如果报「连不上 127.0.0.1:18240」，先调一次 vscreen_ensure（它会借 App 的 Shizuku 权限把守护装好并拉起）。'

function tool(spec) {
  return defineTool({
    name: spec.name,
    description: spec.description,
    parameters: spec.parameters || {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: String(value) }],
    },
    async execute(args) {
      return await spec.run(args || {})
    },
  })
}

export function apply(ctx) {
  const tools = [
    tool({
      name: 'vscreen_ensure',
      description: '确保「受信任虚拟屏」守护在跑：没装就装、没起就起（需要用户已授权 Shizuku）。'
        + '任何 vscreen_* 工具报"连不上"时先调它。手机重启后守护会全灭，也要重新调一次。',
      run: async () => await bridge('ensure'),
    }),
    tool({
      name: 'vscreen_list',
      description: '列出虚拟屏：每块屏的 displayId、分辨率、已经取过多少帧（帧数不动 = 画面是静止的）。'
        + '后台跑应用、看它的画面之前先调这个确认守护在跑。' + ensureNote,
      run: async () => await vsGet('/list'),
    }),
    tool({
      name: 'vscreen_shot',
      description: '取某块虚拟屏当前画面并存成 jpg，返回文件路径 —— **拿到路径后必须用 read_image 读它**，'
        + '否则你看不到画面。文字界面也可以先用 read_image 看，再决定点哪里。'
        + '参数 i 是屏序号（默认 0），w 是最大宽度（越小越快、token 越少，默认不缩放）。',
      parameters: {
        i: { type: 'number', description: '屏序号，默认 0' },
        w: { type: 'number', description: '缩放到的最大宽度（像素），例如 720；不填=原分辨率' },
      },
      run: async (a) => '图片已保存：' + (await shot(a.i || 0, a.w)) + '\n（用 read_image 读这个路径）',
    }),
    tool({
      name: 'vscreen_tap',
      description: '按坐标点击某块虚拟屏。坐标是该屏自己的坐标系（左上角 0,0）—— '
        + '从 vscreen_shot 的画面或 vscreen_info 里判断。' + ensureNote,
      parameters: {
        x: { type: 'number', required: true, description: '横坐标（像素）' },
        y: { type: 'number', required: true, description: '纵坐标（像素）' },
        i: { type: 'number', description: '屏序号，默认 0' },
      },
      run: async (a) => {
        const slot = displayIdOf(await vsGet('/list'), a.i || 0)
        return await shd('input -d ' + slot.displayId + ' tap ' + Number(a.x) + ' ' + Number(a.y))
      },
    }),
    tool({
      name: 'vscreen_swipe',
      description: '在某块虚拟屏上从一点滑到另一点（滚动 / 翻页）。持续移动类（摇杆）需要多次调用。',
      parameters: {
        x1: { type: 'number', required: true },
        y1: { type: 'number', required: true },
        x2: { type: 'number', required: true },
        y2: { type: 'number', required: true },
        ms: { type: 'number', description: '滑动时长（毫秒），默认 300' },
        i: { type: 'number', description: '屏序号，默认 0' },
      },
      run: async (a) => {
        const slot = displayIdOf(await vsGet('/list'), a.i || 0)
        return await shd('input -d ' + slot.displayId + ' swipe ' + Number(a.x1) + ' ' + Number(a.y1)
          + ' ' + Number(a.x2) + ' ' + Number(a.y2) + ' ' + Number(a.ms || 300))
      },
    }),
    tool({
      name: 'vscreen_key',
      description: '给某块虚拟屏发按键。BACK 对副屏有效；HOME / POWER / VOLUME 由系统在**默认屏**处理，'
        + '在虚拟屏上一般没用（这也是文档里说音量键要禁用的原因）。不要用它去按物理屏的键。',
      parameters: {
        key: {
          type: 'string', required: true,
          enum: ['BACK', 'HOME', 'APP_SWITCH', 'ENTER', 'DEL', 'TAB', 'DPAD_UP', 'DPAD_DOWN', 'DPAD_LEFT', 'DPAD_RIGHT'],
        },
        i: { type: 'number', description: '屏序号，默认 0' },
      },
      run: async (a) => {
        const slot = displayIdOf(await vsGet('/list'), a.i || 0)
        return await shd('input -d ' + slot.displayId + ' keyevent ' + String(a.key))
      },
    }),
    tool({
      name: 'vscreen_app',
      description: '把某个应用启动到虚拟屏上（后台跑，不跳屏、不抢前台）。'
        + '参数 pkg 是包名，act 可选（例如 .MainActivity）；'
        + '宿主 App（com.dshmobile.probe）会被守护拒绝 —— 那是硬规则，别尝试绕过。'
        + '想开的应用不在白名单里？那是 phone 那套工具的边界，与虚拟屏无关（这条路不需要无障碍）。',
      parameters: {
        pkg: { type: 'string', required: true, description: '包名，例如 com.tencent.mm' },
        act: { type: 'string', description: 'Activity，可省略（省略则发 LAUNCHER）' },
        i: { type: 'number', description: '屏序号，默认 0' },
      },
      run: async (a) => {
        const body = JSON.stringify({ pkg: String(a.pkg), act: a.act || '', i: Number(a.i || 0), wm: 5 })
        const res = await req(PORT_VSD, '/launch', { method: 'POST', body, tok: token(), timeoutMs: 30000 })
        const text = res.body.toString('utf8')
        if (res.code !== 200) throw new Error('启动失败：HTTP ' + res.code + ' ' + text.slice(0, 200))
        return text + '\n（守护自带的 /launch 在部分机型会失败，失败时退回：`am start --display <displayId> '
          + '--windowingMode 5 -n <pkg>/<act>`，可用 vscreen_list 拿到 displayId）'
      },
    }),
  ]

  // 逐个注册并把结果写成自检文件：项目栽过"文件在仓库里却从没生效"的跟头，
  // 所以"装上了"和"工具真的注册成功"要分开留证据。
  let ok = 0
  const failed = []
  for (const t of tools) {
    try { ctx.tools.register(t); ok++ }
    catch (e) { failed.push(t.name + ': ' + (e && e.message ? e.message : String(e))) }
  }
  try {
    fs.mkdirSync('/sdcard/.dsh-phone', { recursive: true })
    fs.writeFileSync('/sdcard/.dsh-phone/vscreen-loaded.txt',
      'plugin=dsh-vscreen\n'
      + 'time=' + new Date().toISOString() + '\n'
      + 'tools=' + tools.length + '\n'
      + 'registered=' + ok + '\n'
      + 'failed=' + JSON.stringify(failed) + '\n'
      + 'names=' + tools.map((t) => t.name).join(',') + '\n')
  } catch (e) { /* 写不了自检文件不该让插件失效 */ }
}
