# dsh-vscreen —— 受信任虚拟屏的客户端

把「**受信任虚拟屏**」的取画面 / 操作能力做成 DSH 原生工具：
后台把应用跑在虚拟屏上（不跳屏、不抢前台）→ 取那一块屏的画面 → 按坐标点按。

> 方案与两个守护（`dsh.VsDaemon` / `dsh.ShellDaemon`）由群友「**如月雨露**」制作，
> 守护本体随本 App 的安装包分发（`assets/vsd/*.dex`），本插件只做请求转发。

## 工具

| 工具 | 干什么 |
|---|---|
| `vscreen_ensure` | 确保守护在跑（没装就装、没起就起；借 App 的 Shizuku 权限，需要用户授权过） |
| `vscreen_list` | 列虚拟屏：displayId、分辨率、已取帧数 |
| `vscreen_shot` | 取某块屏的画面存成 jpg → **拿路径后用 read_image 读** |
| `vscreen_tap` | 按坐标点击（`input -d <displayId> tap x y`） |
| `vscreen_swipe` | 滑动（滚动 / 翻页） |
| `vscreen_key` | 发按键（BACK 对副屏有效；HOME/POWER/VOLUME 在默认屏处理，一般没用） |
| `vscreen_app` | 把应用启动到虚拟屏上（后台跑） |

## 三条通道

```
:18240  虚拟屏守护   列屏 / 取帧 / 改分辨率 / 放应用上屏
:18242  命令端点     以 shell 身份跑命令（点按 = input -d、也可跑系统命令）
:3099   App 控制桥   唯一能"把守护拉起来"的地方（它走 Shizuku，shell 身份）
```

token：`/run/dsh-vsd/token`（App 每次启动容器重写；守护每个请求都校验它）。
"拉起守护"走 App 桥，用的是 `/run/dsh-phone/token`。

## 边界（别误解）

- **不依赖无障碍**：这条路是 shell + 本地 HTTP，比无障碍快得多，也不受白名单限制；
  但**虚拟屏上跑的应用，与"手机前台"是两回事** —— 想操作用户正在看的那个屏，用 `phone_*` 那套工具。
- **守护的命绑 adb 调试通道**：关掉调试开关或重启手机 → 守护全灭，`vscreen_ensure` 重来一次即可。
- **停止守护会连带杀掉虚拟屏上跑着的应用**（系统行为）。
- `:18242` 等于"常驻在手机上的 adb shell"：能跑系统命令，token 泄露等于交出 shell。
  因此随 App 分发的守护已经**只绑回环 + 每个请求校验 X-Token**（原方案是绑所有网卡 + 零鉴权）。
- 宿主 App（`com.dshmobile.probe`）**永远不会**被放上虚拟屏：跨屏 = 配置变更 = 界面重启，
  守护里对这条是硬拒绝。

## 自检

装好后容器里会有一份注册结果（"装上了"和"工具真的注册成功"是两件事）：

```sh
cat /sdcard/.dsh-phone/vscreen-loaded.txt
```
