// dsh-link —— 把「另一台设备上的 harness」变成本机 agent 可以指挥的对象。
//
// 它做什么：
//   让本机 agent 通过一条已配对的链路，把一项任务交给对端 harness 的 agent
//   执行（对方有自己的模型、工具和权限边界），并把结果取回来。
//
// 它刻意不做什么：
//   · 不 spawn 任何 `dsh` 子进程（ACP 能力不依赖启动器的命令）；
//   · 不注入客户端 UI（避免把界面搞坏；可见性走工具卡片呈现）；
//   · 不碰 /sdcard 存任何密钥（共享存储任何 App 都能读）。
//
// 链路是本端主动拨号的出站连接 —— 因此不依赖本机入站可达性。
import fs from 'node:fs'
import path from 'node:path'
import net from 'node:net'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { LinkClient, LinkError } from './lib/link-client.js'
import { loadState, saveState, generateCode, dshHome, statePath } from './lib/state.js'

// ── 监听模式（电脑侧）用的工具 ─────────────────────────────────────
//
// 关键：ACP 服务端**在进程内挂载**（ctx.plugin(acp, { stream })），
// 不 spawn 任何子进程。于是 ACP 驱动的会话由本进程自己创建 ——
// 它才会进入工作区索引、事件才会流进界面。

/** 把一条 TCP 连接变成 ACP Stream（零第三方依赖），顺带记录帧日志。 */
function streamFromSocket(sock, hooks) {
  const writable = new WritableStream({
    write(msg) {
      hooks.logFrame('出', msg)
      try { hooks.onOutbound?.(msg) } catch {}
      try { sock.write(JSON.stringify(msg) + '\n') } catch {}
    },
  })
  let buf = ''
  let ctrl
  const readable = new ReadableStream({ start(c) { ctrl = c } })
  sock.setEncoding('utf8')
  sock.on('data', (d) => {
    buf += d
    let i
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i); buf = buf.slice(i + 1)
      if (!line.trim()) continue
      let obj
      try { obj = JSON.parse(line) } catch { continue }
      hooks.logFrame('入', obj)
      try { hooks.onInbound?.(obj) } catch {}
      try { ctrl.enqueue(obj) } catch {}
    }
  })
  sock.on('close', () => { try { ctrl.close() } catch {} })
  sock.on('error', () => { try { ctrl.error(new Error('socket error')) } catch {} })
  return { writable, readable }
}

/** dsh-acp 按需加载：万一启动器的安装作用域里没有它，dial 模式仍可正常工作。 */
let acpModCache
async function loadAcp() {
  if (!acpModCache) acpModCache = await import('@deepseek-ai/dsh-acp')
  return acpModCache
}

/** 监听模式：接受对端拨号，配对后把该连接交给进程内挂载的 ACP 服务端。 */
/**
 * 收养一个由 dsh-acp 创建的会话：补上它绕过的两条正规路径。
 *
 * dsh-acp 用 ctx.agents.create() 直接建 agent，绕过了：
 *   1) 权限预设 —— 所以会话保持部署默认（常为 workspace-write，在 Windows 上会让命令直接失败）；
 *   2) 工作区记账 —— 所以会话不会归属任何工作区，只能显示在「未分组」。
 * 这里在 session/new 的响应回来后补做这两件事。
 *
 * 两个服务都用 ctx.get() 取（而非写进 inject）：缺服务时只降级，不会让整个插件加载失败。
 */
async function adoptSession(ctx, sessionId, cwd, cfg, log) {
  const note = (m) => {
    log(m)
    try { fs.appendFileSync(path.join(dshHome(), 'dsh-link-listener.log'), `${new Date().toISOString()} ${m}\n`) } catch {}
  }

  // ── 1) 权限预设（可选：未配置就不动，沿用部署默认） ──
  if (cfg.permissionPreset) {
    try {
      const presets = ctx.get('permissionPresets')
      const sessions = ctx.get('sessions')
      const session = sessions?.get?.(sessionId)
      if (presets && session) {
        presets.set(session, cfg.permissionPreset)
        note(`已把会话 ${sessionId} 的权限预设设为 ${cfg.permissionPreset}`)
      } else {
        note('permissionPresets 或 sessions 不可用，跳过权限预设')
      }
    } catch (e) { note(`设置权限预设失败：${e?.message ?? e}`) }
  }

  // ── 2) 归属工作区 ──
  let registry
  try { registry = ctx.get('workspaceRegistry') } catch { registry = undefined }
  if (!registry || !cwd) { note('workspaceRegistry 不可用或缺 cwd，跳过工作区归属'); return }
  try {
    let workspace = await registry.resolveByPath?.(cwd)
    if (!workspace) workspace = await registry.create(cwd)
    // attachSession 会读该会话的 header 校验 cwd；刚建完可能还没落盘，所以重试等待
    for (let i = 1; i <= 10; i++) {
      try {
        await workspace.attachSession(sessionId)
        note(`已把会话 ${sessionId} 归属到工作区 ${workspace.path ?? cwd}`)
        return
      } catch (e) {
        if (i === 10) { note(`工作区归属失败（已重试 10 次）：${e?.message ?? e}`); return }
        await new Promise((r) => setTimeout(r, 400))
      }
    }
  } catch (e) { note(`准备工作区失败：${e?.message ?? e}`) }
}

function startListener({ ctx, cfg, log, logFrame }) {
  if (!cfg.port) throw new Error('监听模式需要配置 port')
  if (!cfg.expectCode) throw new Error('监听模式需要配置 expectCode（对端要输入的一次性配对码）')

  const server = net.createServer((sock) => {
    const peer = `${sock.remoteAddress}:${sock.remotePort}`
    log(`接入 ${peer}，等待配对握手`)
    let buf = Buffer.alloc(0)
    let mounted = false
    // 本连接的 ACP 挂载实例。必须声明在「连接」这一层：
    // sock.on('close') 处理器在这个作用域里，声明到 onData 里会 ReferenceError。
    let acpFiber = null

    const onData = (chunk) => {
      buf = Buffer.concat([buf, chunk])
      const nl = buf.indexOf(0x0a)
      if (nl < 0) { if (buf.length > 65536) sock.destroy(); return }
      const rest = buf.subarray(nl + 1)
      sock.removeListener('data', onData)

      let msg
      try { msg = JSON.parse(buf.subarray(0, nl).toString('utf8')) }
      catch { log('坏帧，拒绝'); return sock.destroy() }

      if (msg.type !== 'hello' || msg.code !== cfg.expectCode) {
        log(`配对失败（配对码不匹配）来自 ${peer}`)
        try { sock.write(JSON.stringify({ type: 'pair_fail', reason: 'pairing code mismatch' }) + '\n') } catch {}
        return sock.destroy()
      }

      log(`配对成功 ${peer} peer=${JSON.stringify(msg.peer)}`)
      try {
        sock.write(JSON.stringify({
          type: 'pair_ok',
          peer: { name: 'dsh-pc', platform: process.platform, node: process.version },
        }) + '\n')
      } catch { return sock.destroy() }

      // 切到 ACP：先暂停，把多读的字节还回去，接上 Stream 后再恢复
      sock.pause()
      if (rest.length) sock.unshift(rest)
      const pendingNew = new Map()
      const stream = streamFromSocket(sock, {
        logFrame,
        onInbound: (m) => { if (m?.method === 'session/new') pendingNew.set(m.id, m.params?.cwd) },
        onOutbound: (m) => {
          const sid = m?.result?.sessionId
          if (sid && pendingNew.has(m.id)) {
            const cwd = pendingNew.get(m.id)
            pendingNew.delete(m.id)
            adoptSession(ctx, sid, cwd, cfg, log).catch(() => {})
          }
        },
      })
      sock.resume()

      loadAcp().then((acp) => {
        if (mounted) return
        mounted = true
        const model = {}
        if (cfg.provider) model.provider = cfg.provider
        if (cfg.model) model.model = cfg.model
        // 进程内挂载：这就是「电脑端可见」的开关
        acpFiber = ctx.plugin({ name: 'acp-inproc', apply: acp.apply, inject: acp.inject, Config: acp.Config },
                              { ...model, stream })
        log(`已在进程内挂载 ACP 服务端 ${peer}（provider=${cfg.provider || '默认'}, model=${cfg.model || '默认'}）`)
      }).catch((e) => {
        log(`挂载 ACP 失败（安装作用域里可能没有 @deepseek-ai/dsh-acp）：${e?.message ?? e}`)
        try { sock.destroy() } catch {}
      })
    }

    sock.on('data', onData)
    sock.on('error', (e) => { log(`连接出错（已忽略）：${e.code || e.message}`); try { sock.destroy() } catch {} })
    sock.on('close', () => {
      log(`断开 ${peer}`)
      // 连接结束就卸载这条连接的 ACP 实例，否则挂载点与会话会一直累积
      try { acpFiber?.dispose?.() } catch (e) { log(`卸载 ACP 实例失败（已忽略）：${e?.message ?? e}`) }
      finally { acpFiber = null }
    })
  })

  server.on('error', (e) => {
    const m = `监听失败：${e.code || e.message}`
    log(m)
    try { fs.appendFileSync(path.join(dshHome(), 'dsh-link-listener.log'), `${new Date().toISOString()} ${m}\n`) } catch {}
  })
  server.listen(cfg.port, cfg.host || '0.0.0.0', () => {
    log(`LISTENING ${cfg.host || '0.0.0.0'}:${cfg.port}（监听模式）`)
  })
  return server
}

/** 必须与 cordis.patch.yml 里的 id 完全一致，否则静默不生效。 */
export const name = 'link'
/** 只需要工具注册表。 */
export const inject = ['tools']

const PKG = 'dsh-link'

/** 插件自身版本。写进自检文件：这次踩过「无法从文件判断内存里跑的是哪一版」的坑。 */
let PLUGIN_VERSION = '(unknown)'
try {
  PLUGIN_VERSION = JSON.parse(fs.readFileSync(new URL('./package.json', import.meta.url), 'utf8')).version
} catch {}

export function apply(ctx, config = {}) {
  const log = (m) => { try { ctx.logger?.info?.(`[${PKG}] ${m}`) } catch {} }

  // ── 运行态 ──────────────────────────────────────────────────────
  const boot = loadState()
  const cfg = {
    host: config.host ?? boot.host ?? '',
    port: config.port ?? boot.port ?? 0,
    code: config.code ?? boot.code ?? '',
    cwd: config.cwd ?? boot.cwd ?? (process.env.DSH_LINK_PEER_CWD || ''),
    autoApprove: config.autoApprove ?? true,
    askTimeoutMs: config.askTimeoutMs ?? 900000,
    connectTimeoutMs: config.connectTimeoutMs ?? 15000,
    // 监听模式（电脑侧）用
    mode: config.mode ?? 'dial',
    expectCode: config.expectCode ?? config.code ?? boot.code ?? '',
    provider: config.provider ?? '',
    model: config.model ?? '',
    frameLog: config.frameLog !== false,
    // 收养会话时套用的权限预设（留空则沿用部署默认）
    permissionPreset: config.permissionPreset ?? '',
  }
  let sessionId = boot.sessionId ?? null
  let sessionCwd = boot.sessionCwd ?? null
  let client = null
  let lastAsk = { at: null, task: null, sessionId: null, stopReason: null, transcript: '' }
  const started = []

  // 帧日志：追加写到 $DSH_HOME，便于事后取证（原始字节透传时曾经什么都看不到）
  const frameLogPath = path.join(dshHome(), 'dsh-link-frames.log')
  const logFrame = cfg.frameLog
    ? (dir, obj) => {
        try {
          fs.appendFileSync(frameLogPath,
            `${new Date().toISOString()} ${dir} ${JSON.stringify(obj).slice(0, 2000)}\n`)
        } catch {}
      }
    : () => {}

  let sessionAttached = false   // 当前这条连接上，会话是否已认领

  function getClient() {
    if (client && client.phase === 'ready') return client
    client = new LinkClient({
      host: cfg.host, port: cfg.port, code: cfg.code,
      peerName: config.peerName ?? 'dsh-phone',
      autoApprove: cfg.autoApprove,
      logger: log,
    })
    // 新建连接 = 旧的对端 ACP 实例已随上一条连接销毁，需要重新认领会话
    sessionAttached = false
    return client
  }

  /** 确保链路就绪（按需连接 + 初始化 + 认领会话）。 */
  async function ensureReady({ forceNewSession = false } = {}) {
    const c = getClient()
    if (c.phase !== 'ready') {
      await c.connect({ timeoutMs: cfg.connectTimeoutMs })
      await c.initialize()
    }
    const wantCwd = cfg.cwd || process.cwd()
    if (forceNewSession) sessionId = null

    // 这条连接上还没认领会话时：先尝试 session/resume 恢复它。
    // 对端的 ACP 实例是「每条连接一个」，断开即销毁，所以重连后必须重新认领，
    // 否则会报 unknown session。resume 会校验 cwd 必须与持久化的 cwd 一致。
    if (sessionId && !sessionAttached && !forceNewSession) {
      try {
        await c.resumeSession(sessionId, wantCwd)
        sessionAttached = true
        log(`已恢复对端会话 ${sessionId}`)
      } catch (e) {
        log(`恢复对端会话失败（将另建新会话）：${e?.message ?? e}`)
        sessionId = null
        sessionCwd = null
        saveState({ sessionId: null, sessionCwd: null })
      }
    }
    else if (sessionId && sessionCwd && wantCwd && sessionCwd !== wantCwd) {
      // 对端会话的工作目录是创建时固定的：换了目录就得换会话，
      // 否则任务会跑在旧目录里。
      log(`对端工作目录从 ${sessionCwd} 变为 ${wantCwd}，另建会话`)
      sessionId = null
    }
    if (!sessionId) {
      sessionId = await c.newSession(wantCwd)
      sessionCwd = wantCwd
      sessionAttached = true
      saveState({ sessionId, sessionCwd })
      log(`已在对端创建会话 ${sessionId}（cwd=${wantCwd}）`)
    }
    return c
  }

  // ── 工具 ────────────────────────────────────────────────────────

  const textOut = (render) => ({
    schema: { type: 'string' },
    render: (args, value) => [{ type: 'text', text: render ? render(value) : String(value) }],
  })

  const tStatus = defineTool({
    name: 'peer_status',
    description: '查看与对端 harness 的连接状态：是否已配对、对端是谁、最近一次派活和最近的权限请求。'
      + '在派活之前或排查连接问题时先调它。',
    parameters: {},
    output: textOut(),
    async execute() {
      const st = client ? client.status : { phase: 'idle' }
      const lines = [
        `配置的对端：${cfg.host ? `${cfg.host}:${cfg.port}` : '（未配置，先用 peer_pair 设置）'}`,
        `是否已有配对码：${cfg.code ? '是' : '否'}`,
        `链路状态：${st.phase}`,
        st.peer ? `对端身份：${JSON.stringify(st.peer)}` : '对端身份：（未握手）',
        `当前会话：${sessionId ?? '（尚未创建）'}`,
        st.lastError ? `最近错误：${st.lastError}` : '',
        st.closeReason ? `最近断开原因：${st.closeReason}` : '',
        lastAsk.at ? `最近派活：${lastAsk.at} -> ${lastAsk.stopReason ?? '进行中'}` : '最近派活：（无）',
        st.recentPermissions?.length
          ? `最近权限请求：\n${st.recentPermissions.map((p) => `  - ${p.at} ${p.title} -> ${p.decision}`).join('\n')}`
          : '',
        `状态文件：${statePath()}`,
      ].filter(Boolean)
      return lines.join('\n')
    },
  })

  const tPair = defineTool({
    name: 'peer_pair',
    description: '生成一个新的**一次性配对码**，用于与对端 harness 建立信任关系。'
      + '生成后必须把配对码清楚告诉用户：用户需要在对端设备上输入这个码才能完成配对。'
      + '配对码等价于远程执行命令的权限，只应展示给用户本人。',
    parameters: {
      host: { type: 'string', description: '对端地址（IP 或主机名）。给了就一并保存。' },
      port: { type: 'number', description: '对端端口。给了就一并保存。' },
    },
    output: textOut(),
    async execute(args) {
      const code = generateCode()
      const patch = { code }
      if (args.host) { cfg.host = String(args.host); patch.host = cfg.host }
      if (args.port) { cfg.port = Number(args.port); patch.port = cfg.port }
      saveState(patch)
      if (client) { client.close('重新配对'); client = null }
      sessionId = null
      sessionCwd = null
      sessionAttached = false
      saveState({ sessionId: null, sessionCwd: null })
      return [
        `新配对码：${code}`,
        '',
        '请把这个配对码**完整、原样**展示给用户，然后说明：',
        '1. 在对端设备上启动链路监听器，并把该配对码作为期望码传入；',
        `2. 本端随后会主动连到 ${cfg.host ? `${cfg.host}:${cfg.port}` : '对端地址（需要先用本工具补上 host/port，或用 peer_connect 指定）'}。`,
        '',
        '⚠️ 持有配对码等于可以远程执行命令，不要写进任何会被他人看到的地方。',
      ].join('\n')
    },
  })

  const tConnect = defineTool({
    name: 'peer_connect',
    description: '按照已保存的配置（或本次给出的 host/port/配对码）主动连接对端 harness，并完成配对握手。'
      + '链路是出站连接，因此不需要对端能主动连到本机。',
    parameters: {
      host: { type: 'string', description: '覆盖已保存的对端地址' },
      port: { type: 'number', description: '覆盖已保存的对端端口' },
      code: { type: 'string', description: '覆盖已保存的配对码' },
      cwd: { type: 'string', description: '对端会话的工作目录（对端机器上的绝对路径）' },
      newSession: { type: 'boolean', description: '为 true 时在对端另建一个新会话，不复用旧会话' },
    },
    output: textOut(),
    async execute(args) {
      const patch = {}
      if (args.host) { cfg.host = String(args.host); patch.host = cfg.host }
      if (args.port) { cfg.port = Number(args.port); patch.port = cfg.port }
      if (args.code) { cfg.code = String(args.code); patch.code = cfg.code }
      if (args.cwd) { cfg.cwd = String(args.cwd); patch.cwd = cfg.cwd }
      if (Object.keys(patch).length) saveState(patch)
      if (!cfg.host || !cfg.port) throw new Error('还没有配置对端地址：请用 peer_pair 生成配对码并给出 host/port，或用本工具直接指定。')
      if (!cfg.code) throw new Error('还没有配对码：请先用 peer_pair 生成，并在对端输入同一个码。')
      if (client) { client.close('重新连接'); client = null }
      const st = await ensureReady({ forceNewSession: args.newSession === true })
      return `已连上对端并完成配对。\n对端身份：${JSON.stringify(st.peer)}\n当前会话：${sessionId}\n（链路为出站连接，进程重启后会自动重连。）`
    },
  })

  const tDisconnect = defineTool({
    name: 'peer_disconnect',
    description: '断开与对端 harness 的链路。对端已创建的会话会保留，下次连接可以继续。',
    parameters: {},
    output: textOut(),
    async execute() {
      if (!client) return '当前没有活动链路。'
      client.close('用户要求断开')
      client = null
      return '已断开对端链路。会话已保留，下次 peer_ask 会按需重连。'
    },
  })

  const tSessions = defineTool({
    name: 'peer_sessions',
    description: '列出对端 harness 上已持久化、可恢复的会话。用于判断能否接着之前的对话继续干活。',
    parameters: {},
    output: textOut(),
    async execute() {
      const c = await ensureReady()
      const list = await c.listSessions()
      if (!list.length) return '对端没有可恢复的会话。'
      return `对端可恢复会话（${list.length} 条，新到旧）：\n`
        + list.slice(0, 25).map((s) => `  - ${s.sessionId}  ${s.cwd ?? ''}`).join('\n')
    },
  })

  const tAsk = defineTool({
    name: 'peer_ask',
    description: '把一个任务交给**对端 harness 的 agent**（通常是你的电脑）执行，等它做完后返回结果。'
      + '对端是另一个智能体：它有自己的模型、工具和权限边界，不是远程 shell，也看不到你这边的情况，'
      + '所以任务描述必须自包含。'
      + '注意对端的 shell 工具名和沙箱策略可能与你不同：描述任务时说「执行 …」，不要说「用 bash 执行 …」。'
      + '对端的工作目录必须是它机器上的绝对路径，且不要把它自己的临时目录包在里面。',
    parameters: {
      task: { type: 'string', required: true, description: '交给对端 agent 的完整任务描述（自包含）' },
      cwd: { type: 'string', description: '对端机器上的绝对工作目录；省略则用已保存的值' },
      newSession: { type: 'boolean', description: '为 true 时先在对端另建新会话再派活' },
    },
    timeoutMs: 1800000,
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: String(value) }],
      // 给人看的呈现数据：随 tool/result 一起持久化，供 presentResult 使用
      presentationMeta: (_args, value) => ({
        transcript: lastAsk.transcript || String(value),
        sessionId: lastAsk.sessionId,
        stopReason: lastAsk.stopReason,
        toolCalls: lastAsk.toolCalls ?? [],
      }),
    },
    presentCall: (args) => ({
      card: 'terminal',
      title: args.task,
      description: `交给对端 harness agent 执行${cfg.host ? `（${cfg.host}:${cfg.port}）` : ''}`,
    }),
    presentResult: (_args, result) => {
      const meta = result?.meta ?? {}
      const out = meta.transcript || result?.content?.map((c) => c.text ?? '').join('') || ''
      return {
        card: 'terminal',
        title: meta.stopReason ? `对端完成（${meta.stopReason}）` : '对端完成',
        output: out,
      }
    },
    async execute(args) {
      if (args.cwd) { cfg.cwd = String(args.cwd); saveState({ cwd: cfg.cwd }) }
      const c = await ensureReady({ forceNewSession: args.newSession === true })
      const task = String(args.task)
      lastAsk = { at: new Date().toISOString(), task, sessionId, stopReason: null, transcript: '', toolCalls: [] }
      try {
        const r = await c.prompt(sessionId, task, { timeoutMs: cfg.askTimeoutMs })
        lastAsk.stopReason = r.stopReason
        lastAsk.transcript = r.transcript
        lastAsk.toolCalls = r.toolCalls
        if (!r.text.trim()) {
          return `对端 agent 结束了这一轮（${r.stopReason}），但没有产生文本回复。\n\n它的动作：\n${r.transcript || '（无）'}`
        }
        return r.text.trim()
      } catch (err) {
        const msg = err instanceof LinkError ? `${err.message}${err.code ? ` (${err.code})` : ''}` : (err?.message ?? String(err))
        // 链路已断则丢弃实例，下次调用会重连
        if (client && client.phase !== 'ready') client = null
        throw new Error(`派活给对端失败：${msg}`)
      }
    },
  })

  for (const t of [tStatus, tPair, tConnect, tDisconnect, tSessions, tAsk]) {
    try { started.push(t.name); ctx.tools.register(t) }
    catch (e) { log(`注册工具失败 ${t.name}: ${e?.message ?? e}`) }
  }

  let listenerStatus = '(未启用)'
  if (cfg.mode === 'listen') {
    try {
      // ⚠️ 必须注册销毁：插件被重新挂载（profile 热重载）时，若不关闭旧监听器，
      // 新实例会在同一端口上拿到 EADDRINUSE —— 而旧实例的代码仍在内存里，
      // 结果是「新代码没生效、旧监听器还活着」，极难排查。实测踩过。
      ctx.effect(() => {
        const server = startListener({ ctx, cfg, log, logFrame })
        return () => { try { server.close() } catch {} }
      }, 'dsh-link.listener')
      listenerStatus = `listening ${cfg.host || '0.0.0.0'}:${cfg.port}`
      log(`监听模式已启动 ${listenerStatus}`)
    } catch (e) {
      listenerStatus = 'FAILED: ' + (e?.message ?? e)
      log(`监听模式启动失败：${listenerStatus}`)
    }
  }

  // 自检文件：插件"装上了"和"工具真的注册成功"是两件事。
  try {
    const p = path.join(dshHome(), 'dsh-link-loaded.txt')
    fs.writeFileSync(p, [
      `plugin=${PKG}`,
      `version=${PLUGIN_VERSION}`,
      `time=${new Date().toISOString()}`,
      `tools=${started.length}`,
      `names=${started.join(',')}`,
      `statePath=${statePath()}`,
      `configuredHost=${cfg.host || '(none)'}`,
      `listener=${listenerStatus}`,
      `mode=${cfg.mode}`,
      `permissionPreset=${cfg.permissionPreset || '(部署默认)'}`,
      `frameLog=${cfg.frameLog ? frameLogPath : '(disabled)'}`,
      '',
    ].join('\n'))
  } catch {}

  log(`已加载，注册工具 ${started.length} 个：${started.join(', ')}`)
}
