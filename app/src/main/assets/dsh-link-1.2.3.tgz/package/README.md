# dsh-link

把**另一台设备上的 DeepSeek Harness** 变成本机 agent 可以指挥的对象。

装上之后，agent 的工具列表里会多出 `peer_ask`、`peer_status`、`peer_pair`、
`peer_connect`、`peer_disconnect`、`peer_sessions`。用一条**本端主动拨号**的
出站连接与对端配对，然后把任务交给**对端的 agent** 执行并取回结果。

## 设计边界（刻意的）

- **纯 host 侧插件**：不注入任何客户端 UI，因此不存在"客户端插件把界面搞坏"的风险。
  可见性走官方工具呈现（`presentCall` / `presentResult` 的 Terminal 卡片）。
- **不 spawn 任何 `dsh` 子进程**：不依赖本机 `dsh` 命令在 PATH 里，也不依赖 profile 名。
- **绝不把密钥写进 `/sdcard`**：状态落在 `$DSH_HOME/dsh-link.json`（0600）。
- **只出站**：不需要对端能主动连到本机，因此不受本机入站可达性影响。

## 链路两阶段

1. **配对握手**：一行 JSON `{"type":"hello","proto":1,"code":"<配对码>","peer":{...}}`，
   对端回 `{"type":"pair_ok","peer":{...}}` 或 `pair_fail`。
2. **ACP**：此后是按行分帧的 JSON-RPC 2.0（Agent Client Protocol v1），
   与本机 stdio 版一致；对端的权限请求会被自动批准（可用 `autoApprove: false` 关闭）。

## 典型用法

```
peer_pair                      → 生成一次性配对码，请用户在对端输入
peer_connect host=… port=…     → 拨号并完成配对
peer_ask task="…" cwd="…"      → 把任务交给对端 agent，等它做完并返回结果
peer_status                    → 连接状态、最近派活、最近的权限请求
```

## 安全

**配对码等价于在对端机器上执行命令的权限**（对端 ACP 可以挂载 stdio MCP 服务器，
而 DSH 会真的去 spawn 它）。因此：配对码一次性使用、只展示给用户本人、
对端监听器只绑局域网并用完即停。

## 许可

MIT。
